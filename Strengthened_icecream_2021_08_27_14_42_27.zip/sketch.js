var backgroundImage;
var ufoImage;
var asteriodsImage,asteriods;
var jetimage,jet;
var flameImage;
var score = 0;
var gameState = 1;
var PLAY = 1;
var busted;
var END = 0;

function preload(){
  jetimage = loadImage("xd.png");
  ufoImage = loadImage("download-removebg-preview.png");
  asteriodsImage = loadImage("download_2-removebg-preview.png")
;
  backgroundImage = loadImage("space.jpeg");
  flameImage = loadImage("flame-removebg-preview.png");
busted = loadImage("okyer-removebg-preview.png")



}
function setup() {
  createCanvas(1400,700);
  jet = createSprite(700, 600, 50, 50);
  jet.addImage(jetimage);
  jet.scale = 1;
  flames = new Group();
  ufo = new Group();
  stone = new Group();

}

function draw() {
  if(gameState === PLAY){
    background(backgroundImage);  

    
    if(keyDown("SPACE")){
  createFlames();}
    
    if(flames.isTouching(ufo)){
      ufo.destroyEach();
      flames.destroyEach();   
      score = score +1;
    }
    
    if(flames.isTouching(stone)){
      stone.destroyEach();
      flames.destroyEach();    
      score = score +1;      
    }
    jet.x = mouseX;
    
  createUFO();
    createstone()

  }
   
    if(ufo.isTouching(jet)){
      gameState = END;
      
    }
  if(stone.isTouching(jet)){
      gameState = END;
      
    }
    
    if(flames.isTouching(stone)){
      stone.destroyEach();
      flames.destroyEach();    
      score = score +1;      
    }
  if(gameState === END){ 
    stone.destroyEach();
    ufo.destroyEach();
   // flame.destroyEach();
    jet.addImage(busted);
    jet.x = width/2;
    jet.y = height/2;
    
   }
  
  drawSprites();
  fill("white")
  textSize(20)
text("score: "+score,1300,50);}

function createFlames(){
  var  flame = createSprite(Math.round(random(20, 370)),0, 10, 10);
   flame.addImage(flameImage);
   flame.y = 600;
   flame.x = jet.x;
   flame.velocityY = -4;
   flame.lifetime = 200
   flame.scale=0.3;
  flames.add(flame);
   return flame

}
function createstone(){
  if (World.frameCount % 120 == 0){
  var stones = createSprite(Math.round(random(0, 1200)),0, 10, 10);
  stones.addImage(asteriodsImage);
  stones.velocityY = 4;
  stones.velocityX = 1;
  stones.lifetime = 1000;
  stones.scale = 0.5;
    stone.add(stones);
 return stones}
  }
  function createUFO(){
  if (World.frameCount % 80 == 0){
  var UFO = createSprite(Math.round(random(0, 1200)),0, 10, 10);
  UFO.addImage(ufoImage);
  UFO.velocityY = 5;
  UFO.velocityX = 3;
  UFO.lifetime = 1000;
  UFO.scale = 0.5;
    ufo.add(UFO);
 return UFO
  }}

  
  
